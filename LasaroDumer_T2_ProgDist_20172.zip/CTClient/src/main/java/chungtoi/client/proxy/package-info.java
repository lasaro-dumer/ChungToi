@javax.xml.bind.annotation.XmlSchema(namespace = "http://server.chungtoi/")
package chungtoi.client.proxy;
