~/GlassFish_Server/glassfish/bin/asadmin start-domain
