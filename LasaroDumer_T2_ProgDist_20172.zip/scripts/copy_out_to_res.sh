#!/usr/bin/env bash
cp samples/ChungToi-0000.out samples/ChungToi-0000.res
cp samples/ChungToi-0100.out samples/ChungToi-0100.res
cp samples/ChungToi-1000.out samples/ChungToi-1000.res
cp samples/ChungToi-2000.out samples/ChungToi-2000.res
cp samples/ChungToi-2500.out samples/ChungToi-2500.res
cp samples/ChungToi-3000.out samples/ChungToi-3000.res
cp samples/ChungToi-4000.out samples/ChungToi-4000.res
cp samples/ChungToi-4500.out samples/ChungToi-4500.res
