clear && java -jar CTServer/target/CTServer-1.0-jar-with-dependencies.jar

