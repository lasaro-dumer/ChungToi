mvn clean install | grep -e '^\[[[:alpha:]]'
