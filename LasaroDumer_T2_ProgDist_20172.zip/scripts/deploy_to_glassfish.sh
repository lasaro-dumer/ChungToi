~/GlassFish_Server/glassfish/bin/asadmin deploy --property implicitCdiEnabled=false --force=true --contextroot=ctwebservice CTServer/target/CTServer*.war
