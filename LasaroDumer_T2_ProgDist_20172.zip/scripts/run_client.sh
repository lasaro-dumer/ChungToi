clear && java -jar CTClient/target/CTClient-1.0-jar-with-dependencies.jar
